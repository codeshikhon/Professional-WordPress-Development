<?php

add_action( 'woocommerce_before_mini_cart_contents', function() {
   $product_count = WC()->cart->get_cart_contents_count();
 ?>
 <div class="minicart-header">
   <span><?php esc_html_e('My Bag: ', 'hello-elementor-child'); ?></span>
   <?php
   printf(
      '<span>'._n('%1$u item', '%1$u items', $product_count).'</span>',
      esc_html($product_count)
   );
   ?>
 </div>
 <?php
});

add_shortcode('wc_product_price_filter', function() {

   ob_start();
   the_widget( 'WC_Widget_Price_Filter',
      array(
         'title' => esc_html__( 'By Price', 'hello-elementor-child' )
      ),
      array(
         'before_widget' => '<div class="berocket_single_filter_widget %1$s"><div class="bapf_sfilter bapf_ocolaps">',
         'after_widget' => '</div></div>',
         'before_title' => '<div class="bapf_head bapf_colaps_togl"><h3 class="bapf_hascolarr">',
         'after_title' => '<i class="bapf_colaps_smb fa fa-chevron-down"></i></h3></div>',
      )
   );
   return ob_get_clean();

});

add_action( 'wp_enqueue_scripts', function() {
   $js_scripts = "(function($) {
      $(document).on('bapf_ocolaps bapf_ccolaps', '.bapf_sfilter.bapf_ocolaps, .bapf_sfilter.bapf_ccolaps', function(e) {
         let sfilter = $(this).parent().siblings().children('.bapf_sfilter');

         if( sfilter.is('.bapf_ccolaps') ) {
            sfilter.addClass('bapf_ocolaps').removeClass('bapf_ccolaps');
            sfilter.find('.bapf_colaps_smb').addClass('fa-chevron-down').removeClass('fa-chevron-up');
         }
     });
   })(jQuery)";
   wp_add_inline_script( 'berocket_aapf_widget-script', $js_scripts);

   wp_enqueue_script( 'price-filter-ajax', get_stylesheet_directory_uri() . '/assets/js/price-filter-ajax.js', array('wc-price-slider'), false, true );

   wp_localize_script( 'price-filter-ajax', 'priceFilterAjax', array(
      'product_notfound_text' => esc_html__( "It seems we can't find what you're looking for.", 'hello-elementor-child' )
   ));
});

/**
 * Filter WooCommerce Catalog Orderby
 * @hook woocommerce_catalog_orderby
 */
add_filter( 'woocommerce_catalog_orderby', function() {
   return array(
      'menu_order' => __( 'Default', 'hello-elementor-child' ),
      'popularity' => __( 'Popularity', 'hello-elementor-child' ),
      'rating'     => __( 'Rating', 'hello-elementor-child' ),
      'date'       => __( 'New Arrival', 'hello-elementor-child' ),
      'price'      => __( 'Price Low to High', 'hello-elementor-child' ),
      'price-desc' => __( 'Price High to Low', 'hello-elementor-child' ),
   );
});

/**
 * Display Short Description in Product loop
 */
add_action( 'woocommerce_after_shop_loop_item', function() {
   echo '<p class="short-desc"><a href="'.esc_url(get_permalink()).'">'.esc_html(get_the_excerpt()).'</a></p>';
}, 6);

/**
 * Remove and Add Actions
 */
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title' );
add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_title', 5 );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price' );
add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price', 9 );

// Hide Quantity Field from add to cart button
add_action( 'wp_head', function () {
   echo "<style>.woocommerce div.product form.cart div.quantity {display: none !important;}</style>";
});

add_action( 'woocommerce_before_add_to_cart_button', function() {
   more_query_text();
   echo do_shortcode('[wc_product_atts attribute="shipped-in"][yith_wcwl_add_to_wishlist]');
});

function more_query_text() {
   printf(
      '<div class="query"><strong>%1$s</strong> %2$s <a href="https://api.whatsapp.com/send?phone=%4$s"><i class="fab fa-whatsapp"></i> %3$s +%4$s</a></div>',
      esc_html__( 'More Queries?', 'hello-elementor-child' ),
      esc_html__( 'Reach us on', 'hello-elementor-child' ),
      esc_html__( 'at', 'hello-elementor-child' ),
      esc_html__('918130109011', 'hello-elementor-child')
   );
}

/**
 * Customize wpc-smart-quick-view plugins
 */
if( is_plugin_active('woo-smart-quick-view/wpc-smart-quick-view.php') ) {

   add_filter( 'woosq_thumbnails_slick_params_arr', function($options) {
      $options['dots'] = false;
      $options['arrows'] = false;
      $options['asNavFor'] = '.qv-slider-thumbs';
      
      return $options;
   });

   // Add Products Thumbnail Images before <div class="images">
   add_action( 'woosq_before_thumbnails', function( $product ) {
      $thumb_ids = $product->get_gallery_image_ids();

      if ( $product->get_image_id() ) {
         array_unshift( $thumb_ids, $product->get_image_id() );
      }

      if( ! empty($thumb_ids) && count($thumb_ids) > 1 ) {
         echo '<div class="qv-slider-thumbs">';
         foreach ( $thumb_ids as $thumb_id ) {
            echo '<div class="thumb">' . wp_get_attachment_image( $thumb_id, 'thumbnail' ) . '</div>';
         }
         echo '</div>';
      }
   });

   add_action( 'woosq_after_thumbnails', function( $product ) {
      $thumb_ids = $product->get_gallery_image_ids();

      if ( $product->get_image_id() ) {
         array_unshift( $thumb_ids, $product->get_image_id() );
      }

      if( ! empty($thumb_ids) && count($thumb_ids) > 1 ) {
         ?>
         <script>
            jQuery(document).ready(function($) {
               $('.qv-slider-thumbs').slick({
                  slidesToShow: 4,
                  slidesToScroll: 1,
                  asNavFor: '#woosq-popup .thumbnails-ori .images',
                  focusOnSelect: true,
                  vertical: true,
                  draggable: false,
               });
            });
         </script>
         <?php
      }
   });

   /**
    * Add or Remove Hooks
    * Add new Action to Hooks
    */
    remove_action( 'woosq_product_summary', 'woocommerce_template_single_title', 5 );
    add_action( 'woosq_product_summary', function() {
      the_title( '<h2 class="product_title entry-title"><a href="'.esc_url(get_permalink()).'">', '</a></h2>');
    }, 5 );
    remove_action( 'woosq_product_summary', 'woocommerce_template_single_excerpt', 20 );
    add_action( 'woosq_product_summary', 'woocommerce_template_single_excerpt', 11 );
    remove_action( 'woosq_product_summary', 'woocommerce_template_single_rating', 10 );
    add_action( 'woosq_product_summary', 'more_query_text', 25 );

    add_action( 'woosq_product_summary', function() {
      echo '<div id="product-info-accordion">';
    }, 25 );
    
    add_action( 'woosq_product_summary', function() {
      if( get_the_content() ) {
         ?>
         <div class="wc-product-info">
            <h3 class="product-info-title"><?php esc_html_e( 'Description', 'hello-elementor-child' ); ?></h3>
            <div class="product-info-content"><?php the_content(); ?></div>
         </div>
         <?php
      }
    }, 25 );

    add_action( 'woosq_product_summary', function() {
      echo do_shortcode( '[wc_product_atts attribute="shipped-in"][wc_product_atts attribute="care"]' );
    }, 25 );

    add_action( 'woosq_product_summary', function() {
      echo '</div>';
    }, 25 );

    // jQuery UI Accordion
    add_action( 'wp_enqueue_scripts', function() {
      wp_enqueue_script( 'jquery-ui-accordion' );
    });

    add_action( 'woosq_after_summary', function() {
      ?>
      <script>
         jQuery(document).ready(function($) {
            $( "#product-info-accordion" ).accordion({
               header: ".product-info-title",
               active: false,
               collapsible: true,
               heightStyle: "content"
            });
         });
      </script>
      <?php
    });

    remove_action( 'woosq_product_summary', 'woocommerce_template_single_meta', 30 );

}

/**
 * Set thubmain size to Product Images Gallery
 */
add_filter( 'woocommerce_gallery_thumbnail_size', function() {
   return 'thumbnail';
});