<?php
/**
 * GeneratePress child theme functions and definitions.
 *
 * Add your custom PHP in this file.
 * Only edit this file if you have direct access to it on your server (to fix errors if they happen).
 */

// Control core classes for avoid errors
if ( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'cs_framework';

    //
    // Create options
    CSF::createOptions( $prefix, array(
        'menu_title'      => 'My Framework',
        'framework_title' => 'Theme Settings',
        'menu_slug'       => 'cs-framework',
        'footer_text'     => 'My Footer Text',
        'footer_after'    => 'Footer After Text',
        'footer_credit'   => 'Footer Credit Text',
    ) );

    // Global
    CSF::createSection( $prefix, array(
        'title'  => 'Global',
        'fields' => array(
            array(
                'id'                    => 'body-background',
                'type'                  => 'background',
                'title'                 => 'Body Background',
                'background_gradient'   => false,
                'background_origin'     => true,
                'background_clip'       => true,
                'background_blend_mode' => true,
                'default'               => array(
                    'background-color'              => '#111',
                    'background-gradient-color'     => '#555',
                    'background-gradient-direction' => 'to bottom',
                    'background-size'               => 'cover',
                    'background-position'           => 'center center',
                    'background-repeat'             => 'repeat',
                ),
                'output'                => 'body',
            ),

            array(
                'id'         => 'opt-accordion-2',
                'type'       => 'accordion',
                'title'      => 'Accordion',
                'accordions' => array(
                    array(
                        'title'  => 'Color',
                        'icon'   => 'fa fa-heart',
                        'fields' => array(
                            array(
                                'id'    => 'opt-text-1',
                                'type'  => 'text',
                                'title' => 'Text 1',
                            ),
                            array(
                                'id'         => 'opt-text-2',
                                'type'       => 'text',
                                'title'      => 'Text 2',
                                'dependency' => array( 'opt-text-1', '==', 'true' ),
                            ),
                        ),
                    ),
                    array(
                        'title'  => 'Typography',
                        'fields' => array(
                            array(
                                'id'    => 'opt-color-1',
                                'type'  => 'color',
                                'title' => 'Color 1',
                            ),
                            array(
                                'id'    => 'opt-color-2',
                                'type'  => 'color',
                                'title' => 'Color 2',
                            ),
                        ),
                    ),
                ),
                'default'    => array(
                    'opt-text-1'  => 'This is text 1 value',
                    'opt-text-2'  => 'This is text 2 value',
                    'opt-color-1' => '#555',
                    'opt-color-2' => '#999',
                ),
            ),

            array(
                'id'      => 'opt-border-2',
                'type'    => 'border',
                'title'   => 'Border',
                'default' => array(
                    'top'    => '4',
                    'right'  => '8',
                    'bottom' => '4',
                    'left'   => '8',
                    'style'  => 'dashed',
                    'color'  => '#1e73be',
                    'unit'   => 'px',
                ),
            ),

            array(
                'id'       => 'opt-button-set-2',
                'type'     => 'button_set',
                'title'    => 'Button Set with multiple',
                'multiple' => true,
                'options'  => array(
                    'aqua'   => 'Aqua',
                    'cyan'   => 'Cyan',
                    'golden' => 'Golden',
                    'indigo' => 'Indigo',
                    'lime'   => 'Lime',
                    'navy'   => 'Navy',
                    'purple' => 'Purple',
                ),
                'default'  => array( 'cyan', 'indigo', 'purple' ),
            ),

            array(
                'id'      => 'opt-checkbox-2',
                'type'    => 'checkbox',
                'title'   => 'Checkboxes',
                'options' => array(
                    'option-1' => 'Option 1',
                    'option-2' => 'Option 2',
                    'option-3' => 'Option 3',
                ),
                'default' => array( 'option-1', 'option-3' ),
            ),

            array(
                'id'      => 'opt-palette-1',
                'type'    => 'palette',
                'title'   => 'Palette',
                'options' => array(
                    'set1' => array( '#f04e36', '#f36e27', '#f3d430', '#ed1683' ),
                    'set2' => array( '#f9ca06', '#b5b546', '#2f4d48', '#212b2f' ),
                    'set3' => array( '#4153ab', '#6e86c7', '#211f27', '#d69762' ),
                    'set4' => array( '#162526', '#508486', '#C8C6CE', '#B45F1A' ),
                    'set5' => array( '#bbd5ff', '#ccab5e', '#fff55f', '#197c5d' ),
                ),
                'default' => 'set3',
            ),

            array(
                'id'      => 'opt-radio',
                'type'    => 'radio',
                'title'   => 'Radio',
                'options' => array(
                    'option-1' => 'Option 1',
                    'option-2' => 'Option 2',
                    'option-3' => 'Option 3',
                ),
                'default' => 'option-2',
            ),

            array(
                'id'      => 'opt-repeater-2',
                'type'    => 'repeater',
                'title'   => 'Repeater',
                'fields'  => array(

                    array(
                        'id'    => 'opt-text-1',
                        'type'  => 'text',
                        'title' => 'Text',
                    ),

                    array(
                        'id'    => 'opt-text-2',
                        'type'  => 'text',
                        'title' => 'Text',
                    ),

                ),
                'default' => array(
                    array(
                        'opt-text-1' => 'Text 1 default value',
                        'opt-text-2' => 'Text 2 default value',
                    ),
                    array(
                        'opt-text-1' => 'Text 3 default value',
                        'opt-text-2' => 'Text 4 default value',
                    ),
                ),
            ),

            array(
                'id'          => 'opt-select-4',
                'type'        => 'select',
                'title'       => 'Select',
                'chosen'      => true,
                'multiple'    => true,
                'placeholder' => 'Select an option',
                'options'     => array(
                    'option-1' => 'Option 1',
                    'option-2' => 'Option 2',
                    'option-3' => 'Option 3',
                    'option-4' => 'Option 4',
                    'option-5' => 'Option 5',
                    'option-6' => 'Option 6',
                ),
                'default'     => 'option-3',
            ),

            // Select with AJAX search Pages
            array(
                'id'          => 'opt-select-5',
                'type'        => 'select',
                'title'       => 'Select with pages',
                'placeholder' => 'Select a page',
                'chosen'      => true,
                'ajax'        => true,
                'options'     => 'pages',
            ),

            // Select with multiple and sortable AJAX search Posts
            array(
                'id'          => 'opt-select-6',
                'type'        => 'select',
                'title'       => 'Select with posts',
                'placeholder' => 'Select posts',
                'chosen'      => true,
                'ajax'        => true,
                'multiple'    => true,
                'sortable'    => true,
                'options'     => 'posts',
            ),

            // Select with multiple and sortable AJAX search Categories
            array(
                'id'          => 'opt-select-7',
                'type'        => 'select',
                'title'       => 'Select with categories',
                'placeholder' => 'Select categories',
                'chosen'      => true,
                'ajax'        => true,
                'multiple'    => true,
                'sortable'    => true,
                'options'     => 'categories',
            ),

            // Select with AJAX search CPT (custom post type) Posts
            array(
                'id'          => 'opt-select-8',
                'type'        => 'select',
                'title'       => 'Select with CPT (custom post type) posts',
                'placeholder' => 'Select a post',
                'chosen'      => true,
                'ajax'        => true,
                'options'     => 'posts',
                'query_args'  => array(
                    'post_type' => 'your_post_type_name',
                ),
            ),

            // Select with AJAX search CPT (custom post type) Categories
            array(
                'id'          => 'opt-select-9',
                'type'        => 'select',
                'title'       => 'Select with CPT (custom post type) categories',
                'placeholder' => 'Select a category',
                'chosen'      => true,
                'ajax'        => true,
                'options'     => 'categories',
                'query_args'  => array(
                    'taxonomy' => 'your_taxonomy_name',
                ),
            ),

            array(
                'id'      => 'opt-slider-3',
                'type'    => 'slider',
                'title'   => 'Slider',
                'min'     => 0,
                'max'     => 100,
                'step'    => 1,
                'unit'    => 'px',
                'default' => 25,
            ),

            array(
                'id'      => 'opt-sportable-2',
                'type'    => 'sortable',
                'title'   => 'Sortable',
                'fields'  => array(

                    array(
                        'id'    => 'opt-text-1',
                        'type'  => 'text',
                        'title' => 'Text 1',
                    ),

                    array(
                        'id'    => 'opt-text-2',
                        'type'  => 'text',
                        'title' => 'Text 2',
                    ),

                    array(
                        'id'    => 'opt-text-3',
                        'type'  => 'text',
                        'title' => 'Text 3',
                    ),

                ),
                'default' => array(
                    'opt-text-1' => 'This is text 1 default',
                    'opt-text-2' => 'This is text 2 default',
                    'opt-text-3' => 'This is text 3 default',
                ),
            ),

            array(
                'id'      => 'opt-sorter-1',
                'type'    => 'sorter',
                'title'   => 'Sorter',
                'default' => array(
                    'enabled'  => array(
                        'option-1' => 'Option 1',
                        'option-2' => 'Option 2',
                        'option-3' => 'Option 3',
                    ),
                    'disabled' => array(
                        'option-4' => 'Option 4',
                        'option-5' => 'Option 5',
                    ),
                ),
            ),

            array(
                'id'    => 'opt-spacing-1',
                'type'  => 'spacing',
                'title' => 'Spacing',
            ),

            array(
                'id'    => 'opt-spinner-1',
                'type'  => 'spinner',
                'title' => 'Spinner',
            ),

            array(
                'id'      => 'opt-switcher-2',
                'type'    => 'switcher',
                'title'   => 'Switcher',
                'label'   => 'Do you want activate it ?',
                'default' => true,
            ),

            array(
                'id'    => 'opt-tabbed-1',
                'type'  => 'tabbed',
                'title' => 'Tabbed',
                'tabs'  => array(
                    array(
                        'title'  => 'Tab 1',
                        'icon'   => 'fa fa-heart',
                        'fields' => array(
                            array(
                                'id'    => 'opt-text-1',
                                'type'  => 'text',
                                'title' => 'Text',
                            ),
                        ),
                    ),
                    array(
                        'title'  => 'Tab 2',
                        'icon'   => 'fa fa-gear',
                        'fields' => array(
                            array(
                                'id'    => 'opt-color-1',
                                'type'  => 'color',
                                'title' => 'Color',
                            ),
                        ),
                    ),
                ),
            ),

            array(
                'id'    => 'opt-typography-1',
                'type'  => 'typography',
                'title' => 'Typography',
            ),

        ),
    ) );

    // Layout
    CSF::createSection( $prefix, array(
        'title'  => 'Layout',
        'fields' => array(
            array(
                'id'      => 'opt-image-select-2',
                'type'    => 'image_select',
                'title'   => 'Image Select',
                'options' => array(
                    'value-1' => 'http://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
                    'value-2' => 'http://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
                    'value-3' => 'http://codestarframework.com/assets/images/placeholder/80x80-2c3e50.gif',
                ),
                'default' => array( 'value-1', 'value-3' ),
            ),

        ),
    ) );

    // Header
    CSF::createSection( $prefix, array(
        'title'  => 'Header',
        'fields' => array(
            array(
                'id'          => 'opt-color-2',
                'type'        => 'color',
                'title'       => 'Color',
                'default'     => '#ffbc00',
                'output'      => '.site-header',
                'output_mode' => 'background-color',
            ),

            array(
                'id'      => 'opt-color-group-2',
                'type'    => 'color_group',
                'title'   => 'Color Group',
                'options' => array(
                    'color-1' => 'Color 1',
                    'color-2' => 'Color 2',
                    'color-3' => 'Color 3',
                    'color-4' => 'Color 4',
                ),
                'default' => array(
                    'color-1' => '#ffce4b',
                    'color-2' => '#ff595e',
                    'color-3' => '#0052cc',
                    'color-4' => '#000000',
                ),

            ),

            array(
                'id'       => 'opt-date-2',
                'type'     => 'date',
                'title'    => 'Date Advanced',
                'from_to'  => true,
                'settings' => array(
                    'dateFormat'      => 'mm/dd/yy',
                    'changeMonth'     => true,
                    'changeYear'      => true,
                    'showWeek'        => true,
                    'showButtonPanel' => true,
                    'weekHeader'      => 'Week',
                    'monthNamesShort' => array( 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' ),
                    'dayNamesMin'     => array( 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ),
                ),
            ),

            array(
                'id'       => 'opt-datetime-4',
                'type'     => 'datetime',
                'title'    => 'Date and Time',
                'subtitle' => 'Date and Time Both',
                'settings' => array(
                    'enableTime' => true,
                ),
            ),

            array(
                'id'      => 'opt-dimensions-2',
                'type'    => 'dimensions',
                'title'   => 'Dimensions with default',
                'default' => array(
                    'width'  => '100',
                    'height' => '250',
                    'unit'   => 'px',
                ),
            ),

            array(
                'id'      => 'opt-fieldset-2',
                'type'    => 'fieldset',
                'title'   => 'Fieldset',
                'fields'  => array(
                    array(
                        'id'    => 'opt-text',
                        'type'  => 'text',
                        'title' => 'Text',
                    ),
                    array(
                        'id'    => 'opt-color',
                        'type'  => 'color',
                        'title' => 'Color',
                    ),
                    array(
                        'id'    => 'opt-switcher',
                        'type'  => 'switcher',
                        'title' => 'Switcher',
                    ),
                ),
                'default' => array(
                    'opt-text'     => 'Text default value',
                    'opt-color'    => '#ffbc00',
                    'opt-switcher' => true,
                ),
            ),

            array(
                'id'          => 'opt-gallery-2',
                'type'        => 'gallery',
                'title'       => 'Gallery',
                'add_title'   => 'Add Images',
                'edit_title'  => 'Edit Images',
                'clear_title' => 'Remove Images',
            ),

        ),
    ) );

    // Footer
    CSF::createSection( $prefix, array(
        'title'  => 'Footer',
        'fields' => array(

            array(
                'id'      => 'opt-link-2',
                'type'    => 'link',
                'title'   => 'Link',
                'default' => array(
                    'url'    => 'http://codestarframework.com/',
                    'text'   => 'Codestar Framework',
                    'target' => '_blank',
                ),
            ),

            array(
                'id'      => 'opt-link-color-3',
                'type'    => 'link_color',
                'title'   => 'Link Color',
                'color'   => true,
                'hover'   => true,
                'visited' => true,
                'active'  => true,
                'focus'   => true,
                'default' => array(
                    'color'   => '#1e73be',
                    'hover'   => '#259ded',
                    'visited' => '#222',
                    'active'  => '#333',
                    'focus'   => '#111',
                ),
            ),

            array(
                'id'    => 'opt-map-1',
                'type'  => 'map',
                'title' => 'Map',
            ),

            array(
                'id'    => 'opt-media-1',
                'type'  => 'media',
                'title' => 'Media',
            ),

            array(
                'id'          => 'opt-number-4',
                'type'        => 'number',
                'title'       => 'Number',
                'unit'        => '%',
                'output'      => '.site-header',
                'output_mode' => 'width',
                'default'     => 100,
            ),

            array(
               'id'    => 'opt-wp-editor-1',
               'type'  => 'wp_editor',
               'title' => 'WP Editor',
             ),


        ),
    ) );

    // Slider
    CSF::createSection( $prefix, array(
        'title'  => 'Slider',
        'fields' => array(
            array(
                'id'      => 'opt-group-2',
                'type'    => 'group',
                'title'   => 'Group',
                'fields'  => array(
                    array(
                        'id'    => 'opt-text',
                        'type'  => 'text',
                        'title' => 'Text',
                    ),
                    array(
                        'id'    => 'opt-color',
                        'type'  => 'color',
                        'title' => 'Color',
                    ),
                    array(
                        'id'    => 'opt-switcher',
                        'type'  => 'switcher',
                        'title' => 'Switcher',
                    ),
                ),
                'default' => array(
                    array(
                        'opt-text'     => 'This is text default 1',
                        'opt-color'    => '#ffbc00',
                        'opt-switcher' => true,
                    ),
                    array(
                        'opt-text'     => 'This is text default 2',
                        'opt-color'    => '#000',
                        'opt-switcher' => false,
                    ),
                ),
            ),
            array(
                'id'      => 'opt-icon-2',
                'type'    => 'icon',
                'title'   => 'Icon',
                'default' => 'fa fa-heart',
            ),

        ),
    ) );

    // Custom CSS/JS
    CSF::createSection( $prefix, array(
        'title'  => 'Custom CSS/JS',
        'fields' => array(
            array(
                'id'       => 'opt-code-editor-3',
                'type'     => 'code_editor',
                'title'    => 'CSS Editor',
                'settings' => array(
                    'theme' => 'mbo',
                    'mode'  => 'css',
                ),
                'default'  => '.element{ color: #ffbc00; }',
            ),

            array(
                'id'       => 'opt-code-editor-4',
                'type'     => 'code_editor',
                'title'    => 'Javascript Editor',
                'settings' => array(
                    'theme' => 'monokai',
                    'mode'  => 'javascript',
                ),
                'default'  => 'console.log("Hello world");',
            ),

        ),
    ) );

}

add_filter( 'wp_head', function () {
    if ( !function_exists( 'cs_get_option' ) ) {
        function cs_get_option( $option = '', $default = null ) {
            $options = get_option( 'cs_framework' ); // Attention: Set your unique id of the framework
            return ( isset( $options[$option] ) ) ? $options[$option] : $default;
        }
    }

    echo cs_get_option( 'name' );
    echo cs_get_option( 'footer_text' );

    //  var_dump( cs_get_option( 'opt-accordion-2' )['opt-text-1'] );
    //  var_dump( cs_get_option( 'opt-fieldset-2' ) );
    //  var_dump( cs_get_option( 'opt-gallery-2' ) );
    var_dump( cs_get_option( 'opt-repeater-2' ) );
} );