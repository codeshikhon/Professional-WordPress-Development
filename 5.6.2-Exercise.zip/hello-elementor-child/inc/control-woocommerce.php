<?php

add_action( 'woocommerce_before_mini_cart_contents', function() {
   $product_count = WC()->cart->get_cart_contents_count();
 ?>
 <div class="minicart-header">
   <span><?php esc_html_e('My Bag: ', 'hello-elementor-child'); ?></span>
   <?php
   printf(
      '<span>'._n('%1$u item', '%1$u items', $product_count).'</span>',
      esc_html($product_count)
   );
   ?>
 </div>
 <?php
});