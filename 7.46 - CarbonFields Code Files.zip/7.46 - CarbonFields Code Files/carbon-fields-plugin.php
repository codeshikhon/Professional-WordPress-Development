<?php
/**
 * Plugin Name: Carbon Fields Plugin
 * Description: WordPress developer-friendly custom fields for post types, taxonomy terms, users, comments, widgets, options, navigation menus and more.
 * Version: 3.6.0
 * Author: htmlburger
 * Author URI: https://htmlburger.com/
 * Plugin URI: http://carbonfields.net/
 * License: GPL2
 * Requires at least: 5.0
 * Tested up to: 6.2
 * Text Domain: carbon-fields
 * Domain Path: /languages
 */

define( 'Carbon_Fields_Plugin\PLUGIN_FILE', __FILE__ );

define( 'Carbon_Fields_Plugin\RELATIVE_PLUGIN_FILE', basename( dirname( \Carbon_Fields_Plugin\PLUGIN_FILE ) ) . '/' . basename( \Carbon_Fields_Plugin\PLUGIN_FILE ) );

use Carbon_Fields\Container;
use Carbon_Fields\Block;
use Carbon_Fields\Field;

add_action( 'after_setup_theme', 'crb_load' );
function crb_load() {
    require_once 'vendor/autoload.php';
    \Carbon_Fields\Carbon_Fields::boot();
}

/*
 * Custom Fields
================*/
add_action( 'carbon_fields_register_fields', 'crb_attach_theme_options' );
function crb_attach_theme_options() {

    Container::make( 'post_meta', __( 'My Custom Fields', 'crb' ) )
        ->where( 'post_type', '=', 'page' )
        ->set_context( 'advanced' )
        ->add_fields( array(

            Field::make( 'checkbox', 'crb_show_content', __( 'Show Content' ) )
                ->set_help_text( __( 'drag and drop the pin on the map to select location' ) ),

            Field::make( 'text', 'crb_text', 'Text Field' )
                ->set_attribute( 'placeholder', 'Your Name' )
                ->set_conditional_logic( array(
                    array(
                        'field' => 'crb_show_content',
                        'value' => true,
                    ),
                ) ),

            Field::make( 'association', 'crb_association' )
                ->set_types( array(
                    array(
                        'type'      => 'post',
                        'post_type' => 'page',
                    ),
                    array(
                        'type'      => 'post',
                        'post_type' => 'post',
                    ),
                    array(
                        'type'     => 'term',
                        'taxonomy' => 'category',
                    ),
                    array(
                        'type'     => 'term',
                        'taxonomy' => 'post_tag',
                    ),
                    array(
                        'type' => 'user',
                    ),
                    array(
                        'type' => 'comment',
                    ),
                ) ),

            Field::make( 'date', 'crb_event_start_date', __( 'Event Start Date' ) )
                ->set_storage_format( 'F j, Y' )
                ->set_input_format( 'F Y', 'M Y' )
                ->set_picker_options( array(
                    'weekNumbers' => true,
                ) ),

            Field::make( 'file', 'crb_file', __( 'File' ) )
                ->set_value_type( 'url' ),

            Field::make( 'html', 'crb_html', __( 'Section Description' ) )
                ->set_html( sprintf( '<p>%s</p>', __( 'Here, you can add some useful description for the fields below / above this text.' ) ) ),

            Field::make( 'media_gallery', 'crb_media_gallery', __( 'Media Gallery' ) )
                ->set_duplicates_allowed( false ),

            Field::make( 'select', 'crb_content_align', __( 'Text alignment' ) )
                ->add_options( array(
                    'left'   => __( 'Left' ),
                    'center' => __( 'Center' ),
                    'right'  => __( 'Right' ),
                ) ),

            Field::make( 'multiselect', 'crb_available_colors', __( 'Available Colors' ) )
                ->set_options( array(
                    'red'   => 'Red',
                    'green' => 'Green',
                    'blue'  => 'Blue',
                ) ),

            Field::make( 'oembed', 'crb_oembed', __( 'oEmbed' ) ),

            Field::make( 'radio', 'crb_subtitle_styling', __( 'Subtitle text style' ) )
                ->add_options( array(
                    'em'     => __( 'Italic' ),
                    'strong' => __( 'Bold' ),
                    'del'    => __( 'Strike' ),
                ) ),

            Field::make( 'radio_image', 'crb_background_image', __( 'Choose Background Image' ) )
                ->set_options( array(
                    'mountain' => 'https://source.unsplash.com/X1UTzW8e7Q4/800x600',
                    'temple'   => 'https://source.unsplash.com/ioJVccFmWxE/800x600',
                    'road'     => 'https://source.unsplash.com/5c8fczgvar0/800x600',
                ) ),

            Field::make( 'rich_text', 'crb_sidenote', __( 'Sidenote Content' ) ),

            Field::make( 'separator', 'crb_separator', '' ),

            Field::make( 'set', 'crb_set', __( 'Choose Options' ) )
                ->set_options( array(
                    '1' => 1,
                    '2' => 2,
                    '3' => 3,
                    '4' => 4,
                    '5' => 5,
                ) )
                ->limit_options( 2 ),

            Field::make( 'sidebar', 'crb_custom_sidebar', __( 'Select a Sidebar' ) ),

            Field::make( 'complex', 'crb_slider', __( 'Slider' ) )
                ->add_fields( array(
                    Field::make( 'text', 'title', __( 'Slide Title' ) ),
                    Field::make( 'image', 'photo', __( 'Slide Photo' ) ),
                ) ),

            Field::make( 'complex', 'crb_media_item' )
                ->set_duplicate_groups_allowed( false )
                ->add_fields( 'photograph', array(
                    Field::make( 'image', 'image' ),
                    Field::make( 'text', 'caption' ),
                ) )
                ->add_fields( 'movie', array(
                    Field::make( 'file', 'video' ),
                    Field::make( 'text', 'title' ),
                    Field::make( 'text', 'length' ),
                ) ),

        ) );

    Container::make( 'post_meta', 'Slider Data' )
        ->where( 'post_type', '=', 'post' )
        ->add_fields( array(
            Field::make( 'complex', 'crb_slides' )
                ->add_fields( array(
                    Field::make( 'image', 'image' ),
                    Field::make( 'complex', 'slide_fragments' )
                        ->add_fields( array(
                            Field::make( 'text', 'fragment_text' ),
                            Field::make( 'select', 'fragment_position' )
                                ->add_options( array( 'Top Left', 'Top Right', 'Bottom Left', 'Bottom Right' ) ),
                        ) ),
                ) ),
        ) );

    $employees_labels = array(
        'plural_name'   => 'Employees',
        'singular_name' => 'Employee',
    );
    Container::make( 'theme_options', __( 'Theme Options' ) )
        ->add_tab( __( 'Contact Details' ), array(
            Field::make( 'text', 'email', __( 'Email' ) ),
            Field::make( 'textarea', 'address', __( 'Address' ) ),
            Field::make( 'text', 'phone', __( 'Phone' ) ),
        ) )

        ->add_tab( __( 'Social Links' ), array(
            Field::make( 'complex', 'social_links', __( 'Social Links' ) )
                ->add_fields( array(
                    Field::make( 'icon', 'icon', __( 'Icon' ) )
                        ->set_width( 40 )
                        ->add_dashicons_options(),
                    Field::make( 'text', 'url', __( 'Social URL' ) )
                        ->set_width( 60 ),
                ) ),
        ) )

        ->add_tab( __( 'Slider' ), array(
            Field::make( 'complex', 'site_slider', __( 'Slider Items' ) )
                ->add_fields( array(
                    Field::make( 'text', 'title', __( 'Title' ) ),
                    Field::make( 'textarea', 'description', __( 'Description' ) ),
                    Field::make( 'image', 'image', __( 'Image' ) )
                        ->set_type( array( 'image' ) ),
                ) ),
        ) )

        ->add_tab( __( 'Header' ), array(
            Field::make( 'color', 'header_background', __( 'Background Color' ) )
                ->set_palette( array( '#FF0000', '#00FF00', '#0000FF' ) )
                ->set_alpha_enabled( true ),
            Field::make( 'header_scripts', 'site_header_css', __( 'Header CSS' ) ),
        ) )

        ->add_tab( __( 'Footer' ), array(
            Field::make( 'color', 'footer_background', __( 'Background Color' ) )
                ->set_palette( array( '#FF0000', '#00FF00', '#0000FF' ) )
                ->set_alpha_enabled( true ),
            Field::make( 'footer_scripts', 'site_footer_js', __( 'Footer JS' ) ),
            Field::make( 'rich_text', 'copyright', __( 'Copyright' ) ),
        ) );

        /**
         * Custom Blocks
         */
        Block::make( __( 'My Shiny Gutenberg Block' ) )
         ->add_fields( array(
            Field::make( 'text', 'heading', __( 'Block Heading' ) ),
            Field::make( 'image', 'image', __( 'Block Image' ) ),
            Field::make( 'rich_text', 'content', __( 'Block Content' ) ),
         ) )
         ->set_render_callback( function ( $fields, $attributes, $inner_blocks ) {
            ?>

            <div class="block">
               <div class="block__heading">
                  <h1><?php echo esc_html( $fields['heading'] ); ?></h1>
               </div><!-- /.block__heading -->

               <div class="block__image">
                  <?php echo wp_get_attachment_image( $fields['image'], 'full' ); ?>
               </div><!-- /.block__image -->

               <div class="block__content">
                  <?php echo apply_filters( 'the_content', $fields['content'] ); ?>
               </div><!-- /.block__content -->
            </div><!-- /.block -->

            <?php
         } );
}