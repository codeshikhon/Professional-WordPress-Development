<?php
/**
 * GeneratePress child theme functions and definitions.
 *
 * Add your custom PHP in this file.
 * Only edit this file if you have direct access to it on your server (to fix errors if they happen).
 */

add_filter( 'the_content', function ( $content ) {

    if ( is_singular( 'page' ) ) {
        $content .= '<h3>' . carbon_get_post_meta( get_the_ID(), 'crb_text' ) . '</h3>';

        $items = carbon_get_post_meta( get_the_ID(), 'crb_association' );
        foreach ( $items as $item ) {
            $content .= $item['id'];
        }

        $content .= '<h3>' . carbon_get_post_meta( get_the_ID(), 'crb_event_start_date' ) . '</h3>';
        $content .= '<h3>' . carbon_get_post_meta( get_the_ID(), 'crb_file' ) . '</h3>';
        $content .= '<h3>' . carbon_get_post_meta( get_the_ID(), 'crb_content_align' ) . '</h3>';
        $content .= '<h3>' . carbon_get_post_meta( get_the_ID(), 'crb_oembed' ) . '</h3>';
        $content .= '<h3>' . carbon_get_post_meta( get_the_ID(), 'crb_subtitle_styling' ) . '</h3>';
        $content .= '<h3>' . carbon_get_post_meta( get_the_ID(), 'crb_background_image' ) . '</h3>';
        ob_start();
        crb_dynamic_sidebar( 'sidebar-2' );
        $content .= ob_get_clean();
    }

    return $content;
} );

function crb_dynamic_sidebar( $index = 1, $options = array() ) {
    global $wp_registered_sidebars;

    // Get the sidebar index the same way as the dynamic_sidebar() function
    if ( is_int( $index ) ) {
        $index = "sidebar-$index";
    } else {
        $index = sanitize_title( $index );
        foreach ( (array) $wp_registered_sidebars as $key => $value ) {
            if ( sanitize_title( $value['name'] ) == $index ) {
                $index = $key;
                break;
            }
        }
    }

    // Bail if this sidebar doesn't exist
    if ( empty( $wp_registered_sidebars[$index] ) ) {
        return false;
    }

    // Get the current sidebar options
    $sidebar = $wp_registered_sidebars[$index];

    // Update the sidebar options
    $wp_registered_sidebars[$index] = wp_parse_args( $options, $sidebar );

    // Display the sidebar
    $status = dynamic_sidebar( $index );

    // Restore the original sidebar options
    $wp_registered_sidebars[$index] = $sidebar;

    return $status;
}

add_action( 'wp_enqueue_scripts', function () {
   wp_enqueue_style( 'dashicons' );
} );

add_shortcode( 'contact-details', function () {
   $socials = carbon_get_theme_option( 'social_links' );
   $email = carbon_get_theme_option( 'email' );
   $address = carbon_get_theme_option( 'address' );
   $phone = carbon_get_theme_option( 'phone' );

   ob_start();
   if( $email ) echo '<p>Email: ' . sanitize_email( $email ) . '</p>';
   if( $address ) echo '<p>' . sanitize_textarea_field( $address ) . '</p>';
   if( $phone ) echo '<p>' . absint( $phone ) . '</p>';

   if( isset($socials) && !empty($socials) ) {
      foreach( $socials as $social ) {
         if( isset($social['icon']['class']) && isset($social['url']) ) {
            echo '<a href="'.esc_url($social['url']).'" target="_blank"><i class="'.esc_attr($social['icon']['class']).'"></i></a>';
         }
      }
   }

   return ob_get_clean();
} );

add_action( 'wp_head', function () {
   $header_bg = carbon_get_theme_option( 'header_background' );
   $header_bg = $header_bg ? '.site-header {background-color: '.$header_bg.'}' : '';
   ?>
   <style><?php echo $header_bg; ?></style>
   <?php
} );