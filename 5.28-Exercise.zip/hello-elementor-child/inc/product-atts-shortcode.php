<?php

if ( !defined( 'ABSPATH' ) ) {

    exit;

}

function wc_product_atts_shortcode( $atts ) {

    // Shortcode attributes

    $atts = shortcode_atts(
        array(
            'attribute'  => '',
            'hide_empty' => 1, // Must be 1 not true
            'order'      => 'asc',
            'orderby'    => 'name',
        ),
        $atts,
        'wc_product_atts'
    );

    // Start output

    $output = '';

    // Get attribute taxonomies

    $attribute_taxonomies = wc_get_attribute_taxonomies();

    if ( !empty( $attribute_taxonomies ) ) {

        global $product;

        // Loop taxonomies

        foreach ( $attribute_taxonomies as $taxonomy ) {

            // If attribute matches shortcode parameter

            if ( strtolower( $atts['attribute'] ) == $taxonomy->attribute_name ) {

                // Set taxonomy id correctly so it can be used for get_terms() lookup

                $taxonomy_id = 'pa_' . $taxonomy->attribute_name;

                // Get terms

                $terms = wc_get_product_terms( $product->id, $taxonomy_id, array( 'fields' => 'names' ) );
                /* $terms = get_terms(
                array(
                'hide_empty' => $atts['hide_empty'],
                'order'      => $atts['order'],
                'orderby'    => $atts['orderby'],
                'taxonomy'   => $taxonomy_id,
                )
                ); */

                // If terms exist

                if ( !empty( $terms ) ) {

                    // Output the list

                    $output .= '<div class="wc-product-info" id="wcpas-product-attributes-' . esc_attr( $taxonomy_id ) . '">';

                    $output .= '<h3 class="product-info-title">' . esc_html( $taxonomy->attribute_label ) . '</h3>';

                    $output .= '<div class="product-info-content">';

                    foreach ( $terms as $term ) {
                        $output .= '<div>' . wp_kses_post( $term ) . '</div>';
                    }

                    $output .= '</div>';

                    $output .= '</div>';

                }

            }

        }

    }

    return wp_kses_post( $output );

}
add_shortcode( 'wc_product_atts', 'wc_product_atts_shortcode' );
