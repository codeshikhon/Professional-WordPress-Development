(function ($) {

   let megaNavItem = $('.users-megamenu .premium-main-nav-menu>.premium-mega-nav-item');

   megaNavItem.on({
      mouseover: () => {
         megaNavItem.addClass('megamenu-shown');
      },

      mouseout: () => {
         megaNavItem.removeClass('megamenu-shown');
         megaNavItem.find('.premium-mega-content-container>div>section').removeAttr('style');
      }
   });

   $('#close-umenu').on('click', function (e) {
      megaNavItem.removeClass('megamenu-shown');

      setTimeout(() => {
         megaNavItem.find('.premium-mega-content-container>div>section').css('display', 'none');
      }, 600);

      return false;
   });

})(jQuery)