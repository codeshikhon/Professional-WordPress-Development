jQuery(document).ready(function($) {

   let megaNavItem = $('.users-megamenu .premium-main-nav-menu>.premium-mega-nav-item');

   megaNavItem.on({
      mouseover: () => {
         megaNavItem.addClass('megamenu-shown');
      },

      mouseout: () => {
         megaNavItem.removeClass('megamenu-shown');
         megaNavItem.find('.premium-mega-content-container>div>section').removeAttr('style');
      }
   });

   $('#close-umenu').on('click', function (e) {
      megaNavItem.removeClass('megamenu-shown');

      setTimeout(() => {
         megaNavItem.find('.premium-mega-content-container>div>section').css('display', 'none');
      }, 600);

      return false;
   });

   // Get Cookie
   function wproGetCookie(cname) {
      let name = cname + "=";
      let decodedCookie = decodeURIComponent(document.cookie);
      let ca = decodedCookie.split(';');
      for(let i = 0; i <ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
   }

   // Check Cookie
   let itemsInCart = wproGetCookie("woocommerce_items_in_cart");

   // Add Cart Page link inside elementor menu cart
   if( $('.elementor-widget-woocommerce-menu-cart').length > 0 && itemsInCart != "" && itemsInCart == "1" ) {
      $(`<a class="menu-cart-toggle-overlap" href="${wc_add_to_cart_params.cart_url}"></a>`).insertAfter('.elementor-widget-woocommerce-menu-cart .elementor-menu-cart__toggle');
   }

});