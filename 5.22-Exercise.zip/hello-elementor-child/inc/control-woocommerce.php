<?php

add_action( 'woocommerce_before_mini_cart_contents', function() {
   $product_count = WC()->cart->get_cart_contents_count();
 ?>
 <div class="minicart-header">
   <span><?php esc_html_e('My Bag: ', 'hello-elementor-child'); ?></span>
   <?php
   printf(
      '<span>'._n('%1$u item', '%1$u items', $product_count).'</span>',
      esc_html($product_count)
   );
   ?>
 </div>
 <?php
});

add_shortcode('wc_product_price_filter', function() {

   ob_start();
   the_widget( 'WC_Widget_Price_Filter',
      array(
         'title' => esc_html__( 'By Price', 'hello-elementor-child' )
      ),
      array(
         'before_widget' => '<div class="berocket_single_filter_widget %1$s"><div class="bapf_sfilter bapf_ocolaps">',
         'after_widget' => '</div></div>',
         'before_title' => '<div class="bapf_head bapf_colaps_togl"><h3 class="bapf_hascolarr">',
         'after_title' => '<i class="bapf_colaps_smb fa fa-chevron-down"></i></h3></div>',
      )
   );
   return ob_get_clean();

});

add_action( 'wp_enqueue_scripts', function() {
   $js_scripts = "(function($) {
      $(document).on('bapf_ocolaps bapf_ccolaps', '.bapf_sfilter.bapf_ocolaps, .bapf_sfilter.bapf_ccolaps', function(e) {
         let sfilter = $(this).parent().siblings().children('.bapf_sfilter');

         if( sfilter.is('.bapf_ccolaps') ) {
            sfilter.addClass('bapf_ocolaps').removeClass('bapf_ccolaps');
            sfilter.find('.bapf_colaps_smb').addClass('fa-chevron-down').removeClass('fa-chevron-up');
         }
     });
   })(jQuery)";
   wp_add_inline_script( 'berocket_aapf_widget-script', $js_scripts);

   wp_enqueue_script( 'price-filter-ajax', get_stylesheet_directory_uri() . '/assets/js/price-filter-ajax.js', array('wc-price-slider'), false, true );
});