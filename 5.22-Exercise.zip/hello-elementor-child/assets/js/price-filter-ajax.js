jQuery(document).ready(function($) {

   let priceSlider = $('.price_slider');
   if( priceSlider.length > 0 ) {
      $('#min_price, #max_price').on('input', function() {
         let minPrice = parseInt(Math.round($('#min_price').val()));
         let maxPrice = parseInt(Math.round($('#max_price').val()));
         priceSlider.slider( "values", [ minPrice, maxPrice ] );

         $('.price_label .from').text('$'+minPrice);
         $('.price_label .to').text('$'+maxPrice);
      });
   }

});