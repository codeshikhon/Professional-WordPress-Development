jQuery(document).ready(function($) {

   let priceSlider = $('.price_slider');
   if( priceSlider.length > 0 ) {
      $('#min_price, #max_price').on('input', function() {
         let minPrice = parseInt(Math.round($('#min_price').val()));
         let maxPrice = parseInt(Math.round($('#max_price').val()));
         priceSlider.slider( "values", [ minPrice, maxPrice ] );

         let curSymbol = woocommerce_price_slider_params.currency_format_symbol;
         $('.price_label .from').text(curSymbol+minPrice);
         $('.price_label .to').text(curSymbol+maxPrice);
      });
   }

   // Ajax Product Loading with Price Filter
   let $form = $('.berocket_single_filter_widget.woocommerce.widget_price_filter form');
   if( $form.length > 0 ) {
      $form.on('submit', function(e) {
         e.preventDefault();

         let action = $(this).attr('action'),
             requestUrl;

             let urlParams = {};
             urlParams.min_price = parseInt(Math.round($('#min_price').val()));
             urlParams.max_price = parseInt(Math.round($('#max_price').val()));

             let queryString = window.location.search;
             const queryParams = new URLSearchParams(queryString);
             
             if( queryParams.has('filters') ) {
               urlParams.filters = queryParams.get('filters');
             }

             requestUrl = action + '?' + $.param(urlParams);

             window.history.pushState(null, '', requestUrl);

             $.ajax({
               url: requestUrl,
               beforeSend: function () {
                  $('body').append('<div class="bapf_loader_page"><div class="bapf_lcontainer"><span class="bapf_loader"><span class="bapf_lfirst"></span><span class="bapf_lsecond"></span></span></div></div>');
               },
   
               success: function (data) {
                  let items = $(data).find('ul.products').html();
                  let wcPagination = $(data).find('.woocommerce-pagination').html();

                  
                  if( typeof items !== 'undefined' ) {
                     $('ul.products').html(items);

                     if( typeof wcPagination !== 'undefined' ) {
                        $('.woocommerce-pagination').html(wcPagination);
                     } else {
                        $('.woocommerce-pagination').html('');
                     }

                     $('.woocommerce-info').remove();

                  } else {
                     $('ul.products').html('');
                     $('.woocommerce-pagination').html('');
                     $(`<p class="woocommerce-info">${priceFilterAjax.product_notfound_text}</p>`).insertBefore($('ul.products'));
                  }
             
               },
   
               complete: function () {
                  $('.bapf_loader_page').remove();
               },
   
               error: function (xhr, status, error) {
                  $('.bapf_loader_page').remove();
                  console.log( xhr.status + error );
               }
            });
      });
   }

});