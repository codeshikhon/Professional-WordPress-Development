<?php

add_action( 'wp_enqueue_scripts', 'helechild_theme_enqueue_styles', 11 );
if ( !function_exists( 'helechild_theme_enqueue_styles' ) ):
    function helechild_theme_enqueue_styles() {
        wp_enqueue_style( 'helechild-child', get_stylesheet_uri());
        wp_enqueue_script( 'helechild-custom', get_stylesheet_directory_uri() . '/assets/js/custom.js', array('jquery'), false, true );
    }
endif;